import RegisterView from "@/sections/register-view";

export default function Register () {
    return <RegisterView/>
}