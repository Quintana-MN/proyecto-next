import NeedHelp from "@/sections/needhelp-view";

export default function NeedHelpView () {
    return (
        <NeedHelp/>
    )
}