import LoginView from "@/sections/login-view";

export default function Login () {
    return (
        <LoginView/>
    )
}