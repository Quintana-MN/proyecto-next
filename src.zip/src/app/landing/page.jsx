import LandingView from "@/src/sections/landing-view";

export default function Landing () {
    return <LandingView/>
}