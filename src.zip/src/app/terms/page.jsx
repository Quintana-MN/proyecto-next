import Terms from '@/sections/terms-view'

export default function TermsOfService () {
    return (
        <Terms/>
    )
}