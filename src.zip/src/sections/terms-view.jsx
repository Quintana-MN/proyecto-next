export default function Terms () {
    return (
        <>
        
        </>
    )
}